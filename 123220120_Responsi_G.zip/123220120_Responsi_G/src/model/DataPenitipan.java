/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Lab Informatika
 */
    public class DataPenitipan{
        private Integer id;
        private String nama_pemilik;
        private String nama_hewan;
        private String jenis_hewan;
        private String nomor_telepon;
        private Integer durasi;
        private Integer harga;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getNama_pemilik() {
            return nama_pemilik;
        }

        public void setNama_pemilik(String nama_pemilik) {
            this.nama_pemilik = nama_pemilik;
        }

        public String getNama_hewan() {
            return nama_hewan;
        }

        public void setNama_hewan(String nama_hewan) {
            this.nama_hewan = nama_hewan;
        }

        public String getJenis_hewan() {
            return jenis_hewan;
        }

        public void setJenis_hewan(String jenis_hewan) {
            this.jenis_hewan = jenis_hewan;
        }

        public String getNomor_telepon() {
            return nomor_telepon;
        }

        public void setNomor_telepon(String nomor_telepon) {
            this.nomor_telepon = nomor_telepon;
        }

        public Integer getDurasi() {
            return durasi;
        }

        public void setDurasi(Integer durasi) {
            this.durasi = durasi;
        }

        public Integer getHarga() {
            return harga;
        }

        public void setHarga(Integer harga) {
            this.harga = harga;
        }
        
        
    }

