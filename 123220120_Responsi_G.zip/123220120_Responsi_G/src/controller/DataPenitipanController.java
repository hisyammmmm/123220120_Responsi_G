/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAODataPenitipan.DataPenitipanDAO;
import DAOImplement.DataPenitipanImplement;
import model.*;
import pkg123220120_responsi_g.menuUtama;
import javax.swing.JOptionPane;

/**
 *
 * @author Lab Informatika
 */
public class DataPenitipanController {
    menuUtama frame;
    DataPenitipanImplement impDataPenitipan;
    List<DataPenitipan>dataPenitipan;
    
    public DataPenitipanController(menuUtama frame) {
        this.frame = frame;
        impDataPenitipan = new DataPenitipanDAO();
        dataPenitipan = impDataPenitipan.getAll();
    }
    
    public void isiTable() {
        dataPenitipan = impDataPenitipan.getAll();
        modelTabelDataPenitipan modelTDP = new modelTabelDataPenitipan(dataPenitipan);
        frame.getTableDataPenitipan().setModel(modelTDP);
    }
    
//    public void insert() {
//        try {
//            //mengecek field yang kosong
//            i
//        }
//    }
}
